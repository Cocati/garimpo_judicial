from typing import List, Dict
from src.domain.models import Auction, AuctionFilter, Evaluation, EvaluationStatus
from src.application.interfaces import AuctionRepository

class GetPendingAuctionsUseCase:
    """Caso de uso: Recuperar fila de triagem para o usuário."""
    
    def __init__(self, repository: AuctionRepository):
        self.repository = repository

    def execute(self, user_id: str, uf: str = None, cidade: str = None, 
                tipo_bem: str = None, site: str = None) -> List[Auction]:
        
        # Constrói o filtro
        filters = AuctionFilter(
            uf=uf,
            cidade=cidade,
            tipo_bem=tipo_bem,
            site=site
        )
        
        # Delega para o repositório
        return self.repository.get_pending_auctions(user_id, filters)

class SubmitBatchEvaluationUseCase:
    """Caso de uso: Processar a decisão do usuário (Descartar/Analisar)."""
    
    def __init__(self, repository: AuctionRepository):
        self.repository = repository

    def execute(self, user_id: str, items: List[dict], decision: EvaluationStatus) -> int:
        """
        Recebe uma lista de dicionários contendo {'site': 'x', 'id_leilao': 'y'}
        e aplica a mesma decisão para todos.
        """
        evaluations_to_save = []
        
        for item in items:
            evaluation = Evaluation(
                usuario_id=user_id,
                site=item['site'],
                id_leilao=item['id_leilao'],
                avaliacao=decision
            )
            evaluations_to_save.append(evaluation)
            
        return self.repository.save_evaluations(evaluations_to_save)
    
class GetFilterOptionsUseCase:
    def __init__(self, repository):
        self.repository = repository

    def execute(self):
        return self.repository.get_filter_options()

class GetUserStatsUseCase:
    """Caso de uso: Recuperar estatísticas de produtividade do usuário."""
    def __init__(self, repository: AuctionRepository):
        self.repository = repository

    def execute(self, user_id: str) -> Dict[str, int]:
        return self.repository.get_stats(user_id)
