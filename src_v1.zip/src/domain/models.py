from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List

class EvaluationStatus(str, Enum):
    """Define os estados possíveis de uma análise de leilão."""
    DESCARTAR = "Descartar"
    ANALISAR = "Analisar"

@dataclass
class Auction:
    """
    Entidade que representa um Leilão Judicial/Extrajudicial.
    """
    site: str
    id_leilao: str
    titulo: str
    uf: str
    cidade: str
    tipo_leilao: Optional[str] = None
    tipo_bem: Optional[str] = None
    valor_1_praca: Optional[float] = None
    valor_2_praca: Optional[float] = None
    link_detalhe: Optional[str] = None
    imagem_capa: Optional[str] = None

    @property
    def unique_id(self) -> str:
        """Identificador único composto para uso interno."""
        return f"{self.site}_{self.id_leilao}"

@dataclass
class AuctionFilter:
    """Objeto de valor para transporte de critérios de filtro."""
    # Alterado de str para List[str] para suportar seleção múltipla
    uf: Optional[List[str]] = None
    cidade: Optional[List[str]] = None
    tipo_bem: Optional[List[str]] = None
    site: Optional[List[str]] = None
    tipo_leilao: Optional[List[str]] = None

@dataclass
class Evaluation:
    """Entidade que representa a decisão do analista."""
    usuario_id: str
    site: str
    id_leilao: str
    avaliacao: EvaluationStatus
    data_analise: datetime = field(default_factory=datetime.now)
