from sqlalchemy import Column, String, Integer, Float, DateTime, Numeric, Text
from datetime import datetime
from src.infra.database.config import Base

class LeilaoAnaliticoModel(Base):
    __tablename__ = "leiloes_analiticos"

    site = Column(Text, primary_key=True)
    id_leilao = Column(Text, primary_key=True)
    
    id_registro_bruto = Column(Integer) # Vamos usar isso para buscar o ID
    titulo = Column(Text)
    tipo_leilao = Column(Text)
    cidade = Column(Text)
    uf = Column(Text)
    valor_1_praca = Column(Numeric(15, 2))
    valor_2_praca = Column(Numeric(15, 2))
    link_detalhe = Column(Text)
    imagem_capa = Column(Text)
    tipo_bem = Column(Text)
    updated_at = Column(DateTime, default=datetime.now)

class LeilaoAvaliacaoModel(Base):
    __tablename__ = "leiloes_avaliacoes"
    
    usuario_id = Column(Text, primary_key=True)
    site = Column(Text, primary_key=True)
    id_leilao = Column(Text, primary_key=True)
    
    # CORREÇÃO: Adicionada esta coluna que o banco exige
    id_registro_bruto = Column(Integer, nullable=False) 
    
    avaliacao = Column(Text)
    data_analise = Column(DateTime, default=datetime.now)
