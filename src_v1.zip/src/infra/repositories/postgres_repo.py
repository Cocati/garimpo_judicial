from typing import List, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import text, and_, func, distinct

from src.application.interfaces import AuctionRepository
from src.domain.models import Auction, AuctionFilter, Evaluation
from src.infra.database.models_sql import LeilaoAnaliticoModel, LeilaoAvaliacaoModel

class PostgresAuctionRepository(AuctionRepository):
    def __init__(self, session: Session):
        self.session = session

    def get_pending_auctions(self, user_id: str, filters: AuctionFilter) -> List[Auction]:
        # Inicia a query base (Left Join para pegar apenas o que NÃO foi avaliado)
        query = self.session.query(LeilaoAnaliticoModel).outerjoin(
            LeilaoAvaliacaoModel,
            and_(
                LeilaoAnaliticoModel.site == LeilaoAvaliacaoModel.site,
                LeilaoAnaliticoModel.id_leilao == LeilaoAvaliacaoModel.id_leilao,
                LeilaoAvaliacaoModel.usuario_id == user_id
            )
        ).filter(LeilaoAvaliacaoModel.id_leilao == None)

        # --- CORREÇÃO AQUI ---
        # Usamos .in_(...) em vez de == porque os filtros vêm como lista (ex: ['SP'])
        
        if filters.uf:
            query = query.filter(LeilaoAnaliticoModel.uf.in_(filters.uf))
            
        if filters.cidade:
            query = query.filter(LeilaoAnaliticoModel.cidade.in_(filters.cidade))
            
        if filters.tipo_bem:
            query = query.filter(LeilaoAnaliticoModel.tipo_bem.in_(filters.tipo_bem))
            
        if filters.site:
            query = query.filter(LeilaoAnaliticoModel.site.in_(filters.site))
        
        # ---------------------

        results = query.limit(100).all()

        return [
            Auction(
                site=r.site,
                id_leilao=r.id_leilao,
                titulo=r.titulo,
                uf=r.uf,
                cidade=r.cidade,
                tipo_leilao=r.tipo_leilao,
                tipo_bem=r.tipo_bem,
                valor_1_praca=float(r.valor_1_praca) if r.valor_1_praca else 0.0,
                valor_2_praca=float(r.valor_2_praca) if r.valor_2_praca else 0.0,
                link_detalhe=r.link_detalhe,
                imagem_capa=r.imagem_capa
            )
            for r in results
        ]

    def save_evaluations(self, evaluations: List[Evaluation]) -> int:
        count = 0
        try:
            for ev in evaluations:
                # Busca o ID bruto original para manter integridade
                raw_id = self.session.query(LeilaoAnaliticoModel.id_registro_bruto)\
                    .filter_by(site=ev.site, id_leilao=ev.id_leilao)\
                    .scalar()
                
                if raw_id is None: continue

                db_model = LeilaoAvaliacaoModel(
                    usuario_id=ev.usuario_id,
                    site=ev.site,
                    id_leilao=ev.id_leilao,
                    id_registro_bruto=raw_id,
                    avaliacao=ev.avaliacao.value,
                    data_analise=ev.data_analise
                )
                self.session.merge(db_model)
                count += 1
            self.session.commit()
            return count
        except Exception as e:
            self.session.rollback()
            raise e

    def get_filter_options(self) -> Dict[str, List[str]]:
        """Busca valores únicos no banco para preencher os filtros"""
        return {
            "ufs": [r[0] for r in self.session.query(distinct(LeilaoAnaliticoModel.uf)).order_by(LeilaoAnaliticoModel.uf).all() if r[0]],
            "cidades": [r[0] for r in self.session.query(distinct(LeilaoAnaliticoModel.cidade)).order_by(LeilaoAnaliticoModel.cidade).all() if r[0]],
            "tipos": [r[0] for r in self.session.query(distinct(LeilaoAnaliticoModel.tipo_bem)).order_by(LeilaoAnaliticoModel.tipo_bem).all() if r[0]],
            "sites": [r[0] for r in self.session.query(distinct(LeilaoAnaliticoModel.site)).order_by(LeilaoAnaliticoModel.site).all() if r[0]],
        }

    def get_stats(self, user_id: str) -> Dict[str, int]:
        """CONTA REAIS: Quantos 'Analisar' e quantos 'Descartar'."""
        try:
            results = self.session.query(
                LeilaoAvaliacaoModel.avaliacao,
                func.count(LeilaoAvaliacaoModel.id_leilao)
            ).filter(LeilaoAvaliacaoModel.usuario_id == user_id)\
             .group_by(LeilaoAvaliacaoModel.avaliacao).all()
            
            # Inicializa zerado
            stats = {'analisar': 0, 'descartar': 0, 'total_processado': 0}
            
            # Preenche com o retorno do banco
            for status, count in results:
                if status == 'Analisar':
                    stats['analisar'] = count
                elif status == 'Descartar':
                    stats['descartar'] = count
            
            stats['total_processado'] = stats['analisar'] + stats['descartar']
            return stats
        except Exception:
            return {'analisar': 0, 'descartar': 0, 'total_processado': 0}
