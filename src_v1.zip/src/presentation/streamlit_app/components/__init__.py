from .sidebar import render_sidebar
from .dashboard import render_dashboard
from .triage_grid import render_triage_grid # Pode manter por segurança
from .triage_cards import render_triage_cards # <--- ADICIONE ESTE
