import streamlit as st
from src.infra.database.config import SessionLocal
from src.infra.repositories.postgres_repo import PostgresAuctionRepository
from src.application.use_cases import (
    GetPendingAuctionsUseCase, 
    SubmitBatchEvaluationUseCase, 
    GetFilterOptionsUseCase,
    GetUserStatsUseCase # <--- Adicionado
)

@st.cache_resource
def get_services():
    db_session = SessionLocal()
    repo = PostgresAuctionRepository(db_session)
    return {
        "get_auctions": GetPendingAuctionsUseCase(repo),
        "submit_eval": SubmitBatchEvaluationUseCase(repo),
        "get_filters": GetFilterOptionsUseCase(repo),
        "get_stats": GetUserStatsUseCase(repo), # <--- Adicionado
        "repo": repo
    }
