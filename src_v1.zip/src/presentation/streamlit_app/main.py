import sys
import os
import time
import pandas as pd
import streamlit as st
import plotly.express as px # Garantir que o plotly está importado

# --- 1. CONFIGURAÇÃO DA PÁGINA (Obrigatório ser a primeira linha) ---
st.set_page_config(
    page_title="Garimpo Judicial - Triagem",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- 2. SETUP DE PATH ---
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, "../../.."))

if project_root not in sys.path:
    sys.path.append(project_root)

# --- 3. IMPORTAÇÕES DO PROJETO ---
try:
    from src.domain.models import EvaluationStatus
    from src.presentation.streamlit_app.dependencies import get_services
    from src.presentation.streamlit_app.components import (
        render_sidebar, 
        render_dashboard, 
        render_triage_cards
    )
except ImportError as e:
    st.error(f"Erro de Importação: {e}")
    st.info(f"O sistema tentou buscar módulos em: {project_root}")
    st.stop()

# --- FUNÇÃO PRINCIPAL ---
def main():
    st.title("⚖️ Garimpo Judicial")
    
    st.markdown("""
    <style>
        .block-container { padding-top: 2rem; }
    </style>
    """, unsafe_allow_html=True)

    if "user_id" not in st.session_state:
        st.session_state["user_id"] = "Julio"

    # --- 4. CARREGAMENTO DE DADOS ---
    try:
        services = get_services()
        
        # A. Busca Opções para os Filtros
        filter_options = services["get_filters"].execute()
        
        # B. Renderiza a Sidebar
        filters = render_sidebar(
            unique_ufs=filter_options.get("ufs", []),
            unique_cities=filter_options.get("cidades", []),
            unique_types=filter_options.get("tipos", []),
            unique_sites=filter_options.get("sites", [])
        )

        # C. Busca os Leilões Pendentes (Backlog)
        auctions_list = services["get_auctions"].execute(
            user_id=st.session_state["user_id"],
            uf=filters["uf"],
            cidade=filters["cidade"],
            tipo_bem=filters["tipo_bem"],
            site=filters["site"]
        )
        
        df = pd.DataFrame([vars(a) for a in auctions_list]) if auctions_list else pd.DataFrame()

        # D. Busca Estatísticas REAIS do Usuário
        # Removemos o mock e usamos o serviço conectado ao banco
        user_stats = services["get_stats"].execute(st.session_state["user_id"])

    except Exception as e:
        st.error(f"Erro ao carregar dados: {e}")
        return

    # --- 5. DASHBOARD ---
    render_dashboard(df, user_stats)

    # --- 6. VISUALIZAÇÃO EM CARDS ---
    if not df.empty:
        current_decisions = render_triage_cards(df)

        st.markdown("---")
        
        count_processed = len(current_decisions)
        col_msg, col_btn = st.columns([3, 1])

        with col_msg:
            if count_processed > 0:
                st.success(f"✅ **{count_processed}** itens prontos para serem salvos.")
            else:
                st.info("ℹ️ Classifique os itens acima para liberar o envio.")

        with col_btn:
            btn_disabled = (count_processed == 0)
            if st.button(f"Processar Lote ({count_processed})", type="primary", use_container_width=True, disabled=btn_disabled):
                _process_batch(services, current_decisions)

    else:
        st.markdown("<br><br>", unsafe_allow_html=True)
        # Verifica se algum filtro está ativo
        has_filters = any(filters.values())
        
        if has_filters:
            st.warning("⚠️ Nenhum leilão encontrado para estes filtros.")
        else:
            st.success("🎉 Parabéns! Você zerou a fila de triagem.")
            st.balloons()

def _process_batch(services, decisions_dict):
    try:
        to_analyze = []
        to_discard = []

        for item in decisions_dict.values():
            payload = {'site': item['site'], 'id_leilao': item['id_leilao']}
            
            if item['decisao'] == "Analisar":
                to_analyze.append(payload)
            elif item['decisao'] == "Descartar":
                to_discard.append(payload)

        user_id = st.session_state["user_id"]

        if to_discard:
            services["submit_eval"].execute(user_id, to_discard, EvaluationStatus.DESCARTAR)
        
        if to_analyze:
            services["submit_eval"].execute(user_id, to_analyze, EvaluationStatus.ANALISAR)

        st.toast("🚀 Decisões salvas com sucesso!", icon="✅")
        
        for key in list(st.session_state.keys()):
            if key.startswith("decision_"):
                del st.session_state[key]

        time.sleep(1.0)
        st.rerun()

    except Exception as e:
        st.error(f"❌ Erro ao salvar lote: {e}")

if __name__ == "__main__":
    main()
