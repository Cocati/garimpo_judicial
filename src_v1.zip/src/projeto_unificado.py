
# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/consolida.py ====
#!/usr/bin/env python3
from pathlib import Path
import argparse
import sys

def _coletar_py(raiz: Path, ignorar_dirs: set):
    for p in raiz.rglob("*.py"):
        # pula se alguma parte do caminho estiver na lista de ignorados
        if any(part in ignorar_dirs for part in p.parts):
            continue
        yield p

def consolidar(raiz: str, saida: str, ignorar_dirs: set):
    raiz_path = Path(raiz).resolve()
    saida_path = Path(saida).resolve()

    arquivos = [p for p in _coletar_py(raiz_path, ignorar_dirs) if p.resolve() != saida_path]
    print(f"🔎 Encontrados {len(arquivos)} arquivos .py sob '{raiz_path}'")

    if not arquivos:
        print("⚠️ Nenhum arquivo .py encontrado (ou tudo foi ignorado).")
        return 1

    with open(saida_path, "w", encoding="utf-8") as w:
        for i, p in enumerate(arquivos, 1):
            print(f"[{i}/{len(arquivos)}] Processando: {p}")
            try:
                conteudo = p.read_text(encoding="utf-8", errors="replace")
            except Exception as e:
                print(f"⚠️ Erro ao ler {p}: {e}", file=sys.stderr)
                continue
            w.write(f"\n# ==== Início do arquivo: {p} ====\n")
            w.write(conteudo)
            w.write(f"\n# ==== Fim do arquivo: {p} ====\n")

    print(f"✅ Saída escrita em: {saida_path}")
    return 0

def main():
    parser = argparse.ArgumentParser(description="Consolida todos os .py em um único arquivo.")
    parser.add_argument("--root", default=".", help="Pasta raiz do projeto (default: .)")
    parser.add_argument("--out", default="projeto_unificado.py", help="Arquivo de saída")
    parser.add_argument(
        "--ignore", nargs="*", default=[
            "__pycache__", ".git", ".idea", ".venv", "venv", "env",
            "build", "dist", "site-packages"  # adicione "Lib" aqui se quiser pular essa pasta
        ],
        help="Nomes de pastas a ignorar (separadas por espaço)."
    )
    args = parser.parse_args()
    # transforma em set para busca mais rápida
    ignorar = set(args.ignore)
    sys.exit(consolidar(args.root, args.out, ignorar))

if __name__ == "__main__":
    main()


# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/consolida.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/application/use_cases.py ====
from typing import List, Dict
from src.domain.models import Auction, AuctionFilter, Evaluation, EvaluationStatus
from src.application.interfaces import AuctionRepository

class GetPendingAuctionsUseCase:
    """Caso de uso: Recuperar fila de triagem para o usuário."""
    
    def __init__(self, repository: AuctionRepository):
        self.repository = repository

    def execute(self, user_id: str, uf: str = None, cidade: str = None, 
                tipo_bem: str = None, site: str = None) -> List[Auction]:
        
        # Constrói o filtro
        filters = AuctionFilter(
            uf=uf,
            cidade=cidade,
            tipo_bem=tipo_bem,
            site=site
        )
        
        # Delega para o repositório
        return self.repository.get_pending_auctions(user_id, filters)

class SubmitBatchEvaluationUseCase:
    """Caso de uso: Processar a decisão do usuário (Descartar/Analisar)."""
    
    def __init__(self, repository: AuctionRepository):
        self.repository = repository

    def execute(self, user_id: str, items: List[dict], decision: EvaluationStatus) -> int:
        """
        Recebe uma lista de dicionários contendo {'site': 'x', 'id_leilao': 'y'}
        e aplica a mesma decisão para todos.
        """
        evaluations_to_save = []
        
        for item in items:
            evaluation = Evaluation(
                usuario_id=user_id,
                site=item['site'],
                id_leilao=item['id_leilao'],
                avaliacao=decision
            )
            evaluations_to_save.append(evaluation)
            
        return self.repository.save_evaluations(evaluations_to_save)
    
class GetFilterOptionsUseCase:
    def __init__(self, repository):
        self.repository = repository

    def execute(self):
        return self.repository.get_filter_options()

class GetUserStatsUseCase:
    """Caso de uso: Recuperar estatísticas de produtividade do usuário."""
    def __init__(self, repository: AuctionRepository):
        self.repository = repository

    def execute(self, user_id: str) -> Dict[str, int]:
        return self.repository.get_stats(user_id)

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/application/use_cases.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/application/interfaces.py ====
from abc import ABC, abstractmethod
from typing import List, Dict
from src.domain.models import Auction, AuctionFilter, Evaluation

class AuctionRepository(ABC):
    """
    Contrato (Interface) para acesso a dados de leilões.
    Qualquer banco de dados (Postgres, Mongo, Memory) deve implementar isso.
    """

    @abstractmethod
    def get_pending_auctions(self, user_id: str, filters: AuctionFilter) -> List[Auction]:
        """
        Retorna leilões que correspondem aos filtros E que ainda não foram
        avaliados pelo usuário específico.
        """
        pass

    @abstractmethod
    def save_evaluations(self, evaluations: List[Evaluation]) -> int:
        """
        Persiste uma lista de avaliações (Batch update).
        Retorna o número de registros salvos.
        """
        pass
        
    @abstractmethod
    def get_stats(self) -> Dict[str, int]:
        """Retorna dados agregados para o dashboard."""
        pass

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/application/interfaces.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/domain/models.py ====
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List

class EvaluationStatus(str, Enum):
    """Define os estados possíveis de uma análise de leilão."""
    DESCARTAR = "Descartar"
    ANALISAR = "Analisar"

@dataclass
class Auction:
    """
    Entidade que representa um Leilão Judicial/Extrajudicial.
    """
    site: str
    id_leilao: str
    titulo: str
    uf: str
    cidade: str
    tipo_leilao: Optional[str] = None
    tipo_bem: Optional[str] = None
    valor_1_praca: Optional[float] = None
    valor_2_praca: Optional[float] = None
    link_detalhe: Optional[str] = None
    imagem_capa: Optional[str] = None

    @property
    def unique_id(self) -> str:
        """Identificador único composto para uso interno."""
        return f"{self.site}_{self.id_leilao}"

@dataclass
class AuctionFilter:
    """Objeto de valor para transporte de critérios de filtro."""
    # Alterado de str para List[str] para suportar seleção múltipla
    uf: Optional[List[str]] = None
    cidade: Optional[List[str]] = None
    tipo_bem: Optional[List[str]] = None
    site: Optional[List[str]] = None
    tipo_leilao: Optional[List[str]] = None

@dataclass
class Evaluation:
    """Entidade que representa a decisão do analista."""
    usuario_id: str
    site: str
    id_leilao: str
    avaliacao: EvaluationStatus
    data_analise: datetime = field(default_factory=datetime.now)

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/domain/models.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/dependencies.py ====
import streamlit as st
from src.infra.database.config import SessionLocal
from src.infra.repositories.postgres_repo import PostgresAuctionRepository
from src.application.use_cases import (
    GetPendingAuctionsUseCase, 
    SubmitBatchEvaluationUseCase, 
    GetFilterOptionsUseCase,
    GetUserStatsUseCase # <--- Adicionado
)

@st.cache_resource
def get_services():
    db_session = SessionLocal()
    repo = PostgresAuctionRepository(db_session)
    return {
        "get_auctions": GetPendingAuctionsUseCase(repo),
        "submit_eval": SubmitBatchEvaluationUseCase(repo),
        "get_filters": GetFilterOptionsUseCase(repo),
        "get_stats": GetUserStatsUseCase(repo), # <--- Adicionado
        "repo": repo
    }

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/dependencies.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/styles.py ====
import streamlit as st

def apply_custom_styles():
    st.markdown("""
    <style>
        /* Força altura da linha */
        div[data-testid="stDataEditor"] table {
            --row-height: 150px !important;
        }
        div[data-testid="stDataEditor"] td {
            vertical-align: middle !important;
            font-size: 16px;
        }
        /* Ajuste de container para remover espaços brancos sobrando */
        .block-container {
            padding-top: 1rem;
            padding-bottom: 2rem;
            max-width: 98% !important;
        }
        div[data-testid="stDataEditor"] th {
            background-color: #f0f2f6;
            min-height: 40px;
            font-size: 15px;
        }
    </style>
    """, unsafe_allow_html=True)

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/styles.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/components.py ====
import streamlit as st
import plotly.express as px
import pandas as pd
from typing import Dict, Any, List

# ALTERAÇÃO: Agora aceitamos 4 listas como parâmetros
def render_sidebar(unique_ufs: List[str], unique_cities: List[str], unique_types: List[str], unique_sites: List[str]) -> Dict[str, Any]:
    with st.sidebar:
        st.header("🔍 Filtros de Triagem")
        
        # Filtros vindos do Banco
        uf = st.selectbox("Estado (UF)", options=["Todos"] + unique_ufs)
        
        # Dica: Se quiser filtrar cidade baseado na UF selecionada, precisaria de mais lógica, 
        # mas vamos carregar todas por enquanto para simplificar.
        cidade = st.selectbox("Cidade", options=["Todas"] + unique_cities)
        
        tipo_bem = st.multiselect("Tipo de Bem", options=unique_types)
        site = st.multiselect("Leiloeiro", options=unique_sites)
        
        aplicar = st.button("Aplicar Filtros", type="primary", use_container_width=True)
        
        return {
            "uf": None if uf == "Todos" else uf,
            "cidade": None if cidade == "Todas" else cidade,
            "tipo_bem": tipo_bem if tipo_bem else None,
            "site": site if site else None,
            "clicked": aplicar
        }

# ... (Mantenha o render_dashboard igual) ...
def render_dashboard(df: pd.DataFrame):
    if df.empty:
        return

    with st.expander("📊 Ver Estatísticas da Carteira (Clique para expandir)", expanded=False):
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if 'tipo_bem' in df.columns:
                fig_tipo = px.pie(df, names='tipo_bem', title='Tipo Imóvel', hole=0.5)
                fig_tipo.update_layout(showlegend=False, height=250, margin=dict(t=30, b=0, l=0, r=0))
                st.plotly_chart(fig_tipo, use_container_width=True)

        with col2:
            if 'tipo_leilao' in df.columns:
                fig_mod = px.pie(df, names='tipo_leilao', title='Modalidade', hole=0.5)
                fig_mod.update_layout(showlegend=False, height=250, margin=dict(t=30, b=0, l=0, r=0))
                st.plotly_chart(fig_mod, use_container_width=True)

        with col3:
            if 'site' in df.columns:
                fig_site = px.pie(df, names='site', title='Leiloeiro', hole=0.5)
                fig_site.update_layout(showlegend=False, height=250, margin=dict(t=30, b=0, l=0, r=0))
                st.plotly_chart(fig_site, use_container_width=True)

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/components.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/main.py ====
import sys
import os
import time
import pandas as pd
import streamlit as st
import plotly.express as px # Garantir que o plotly está importado

# --- 1. CONFIGURAÇÃO DA PÁGINA (Obrigatório ser a primeira linha) ---
st.set_page_config(
    page_title="Garimpo Judicial - Triagem",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- 2. SETUP DE PATH ---
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, "../../.."))

if project_root not in sys.path:
    sys.path.append(project_root)

# --- 3. IMPORTAÇÕES DO PROJETO ---
try:
    from src.domain.models import EvaluationStatus
    from src.presentation.streamlit_app.dependencies import get_services
    from src.presentation.streamlit_app.components import (
        render_sidebar, 
        render_dashboard, 
        render_triage_cards
    )
except ImportError as e:
    st.error(f"Erro de Importação: {e}")
    st.info(f"O sistema tentou buscar módulos em: {project_root}")
    st.stop()

# --- FUNÇÃO PRINCIPAL ---
def main():
    st.title("⚖️ Garimpo Judicial")
    
    st.markdown("""
    <style>
        .block-container { padding-top: 2rem; }
    </style>
    """, unsafe_allow_html=True)

    if "user_id" not in st.session_state:
        st.session_state["user_id"] = "Julio"

    # --- 4. CARREGAMENTO DE DADOS ---
    try:
        services = get_services()
        
        # A. Busca Opções para os Filtros
        filter_options = services["get_filters"].execute()
        
        # B. Renderiza a Sidebar
        filters = render_sidebar(
            unique_ufs=filter_options.get("ufs", []),
            unique_cities=filter_options.get("cidades", []),
            unique_types=filter_options.get("tipos", []),
            unique_sites=filter_options.get("sites", [])
        )

        # C. Busca os Leilões Pendentes (Backlog)
        auctions_list = services["get_auctions"].execute(
            user_id=st.session_state["user_id"],
            uf=filters["uf"],
            cidade=filters["cidade"],
            tipo_bem=filters["tipo_bem"],
            site=filters["site"]
        )
        
        df = pd.DataFrame([vars(a) for a in auctions_list]) if auctions_list else pd.DataFrame()

        # D. Busca Estatísticas REAIS do Usuário
        # Removemos o mock e usamos o serviço conectado ao banco
        user_stats = services["get_stats"].execute(st.session_state["user_id"])

    except Exception as e:
        st.error(f"Erro ao carregar dados: {e}")
        return

    # --- 5. DASHBOARD ---
    render_dashboard(df, user_stats)

    # --- 6. VISUALIZAÇÃO EM CARDS ---
    if not df.empty:
        current_decisions = render_triage_cards(df)

        st.markdown("---")
        
        count_processed = len(current_decisions)
        col_msg, col_btn = st.columns([3, 1])

        with col_msg:
            if count_processed > 0:
                st.success(f"✅ **{count_processed}** itens prontos para serem salvos.")
            else:
                st.info("ℹ️ Classifique os itens acima para liberar o envio.")

        with col_btn:
            btn_disabled = (count_processed == 0)
            if st.button(f"Processar Lote ({count_processed})", type="primary", use_container_width=True, disabled=btn_disabled):
                _process_batch(services, current_decisions)

    else:
        st.markdown("<br><br>", unsafe_allow_html=True)
        # Verifica se algum filtro está ativo
        has_filters = any(filters.values())
        
        if has_filters:
            st.warning("⚠️ Nenhum leilão encontrado para estes filtros.")
        else:
            st.success("🎉 Parabéns! Você zerou a fila de triagem.")
            st.balloons()

def _process_batch(services, decisions_dict):
    try:
        to_analyze = []
        to_discard = []

        for item in decisions_dict.values():
            payload = {'site': item['site'], 'id_leilao': item['id_leilao']}
            
            if item['decisao'] == "Analisar":
                to_analyze.append(payload)
            elif item['decisao'] == "Descartar":
                to_discard.append(payload)

        user_id = st.session_state["user_id"]

        if to_discard:
            services["submit_eval"].execute(user_id, to_discard, EvaluationStatus.DESCARTAR)
        
        if to_analyze:
            services["submit_eval"].execute(user_id, to_analyze, EvaluationStatus.ANALISAR)

        st.toast("🚀 Decisões salvas com sucesso!", icon="✅")
        
        for key in list(st.session_state.keys()):
            if key.startswith("decision_"):
                del st.session_state[key]

        time.sleep(1.0)
        st.rerun()

    except Exception as e:
        st.error(f"❌ Erro ao salvar lote: {e}")

if __name__ == "__main__":
    main()

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/main.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/components/triage_cards.py ====
import streamlit as st
import pandas as pd

def render_triage_cards(df: pd.DataFrame):
    """
    Renderiza os leilões em formato de Cards verticais com altura de imagem fixa.
    Retorna um dicionário com as decisões tomadas.
    """
    if df.empty:
        # Se o dataframe estiver vazio após a filtragem do main, não mostra nada.
        return {}

    # Sanitização básica: Garante que tem ID, pega os primeiros 15 e reseta o índice
    df_clean = df.dropna(subset=['id_leilao']).head(15).reset_index(drop=True)
    
    if df_clean.empty:
         return {}

    # Dicionário para guardar as decisões temporárias
    decisions = {}

    # Estilo CSS para detalhes do card (exceto a imagem, que faremos inline)
    st.markdown("""
    <style>
        /* Ajuste fino para o container do card */
        [data-testid="stVerticalBlock"] > [style*="flex-direction: column;"] > [data-testid="stVerticalBlock"] {
            border: 1px solid #444;
            border-radius: 12px;
            padding: 15px;
            background-color: #262730; /* Cor de fundo do card */
        }
        .big-font { font-size: 16px !important; font-weight: 600; line-height: 1.4; margin-bottom: 10px;}
        .price-label { font-size: 12px; color: #aaa; }
        .price-value { font-size: 15px; font-weight: bold; }
        .price-value-2 { font-size: 15px; font-weight: bold; color: #4CAF50; } /* Verde para 2ª praça */
        .link-edital { font-size: 13px; text-decoration: none; color: #4da6ff !important; }
    </style>
    """, unsafe_allow_html=True)
    
    st.write(f"Exibindo {len(df_clean)} oportunidades")

    # --- LOOP DOS CARDS ---
    for index, row in df_clean.iterrows():
        id_leilao = str(row['id_leilao'])
        
        # Cria um container para cada leilão
        with st.container():
            # Layout: Imagem (pequena) | Informações (grande) | Ação (pequena)
            col_img, col_info, col_action = st.columns([1.2, 2.3, 1])
            
            # --- 1. COLUNA DA IMAGEM (FIXA) ---
            with col_img:
                img_url = row.get('imagem_capa')
                
                # Se não tiver URL, usa um placeholder do mesmo tamanho
                if not img_url or pd.isna(img_url):
                    img_url = "https://via.placeholder.com/300x220?text=Sem+Foto"

                # CSS HACK: Usamos HTML direto para forçar a altura e o corte (object-fit)
                # height: 220px -> Define a altura fixa
                # object-fit: cover -> Corta o excesso da imagem sem esticar, centralizando o foco.
                st.markdown(
                    f"""
                    <img src="{img_url}" 
                         style="width: 100%; height: 220px; object-fit: cover; border-radius: 8px;" 
                         alt="Foto do bem">
                    """,
                    unsafe_allow_html=True
                )
                
                st.caption(f"ID: {id_leilao} | {row.get('site', 'N/A')}")

            # --- 2. COLUNA DE INFORMAÇÕES ---
            with col_info:
                # Título com classe CSS para limitar tamanho
                titulo = row.get('titulo', 'Sem Título')
                st.markdown(f"<div class='big-font'>{titulo}</div>", unsafe_allow_html=True)
                
                # Exibição de Valores Formatados
                v1 = float(row.get('valor_1_praca', 0) or 0)
                v2 = float(row.get('valor_2_praca', 0) or 0)
                
                c_v1, c_v2 = st.columns(2)
                with c_v1:
                    st.markdown("<span class='price-label'>1ª Praça:</span>", unsafe_allow_html=True)
                    st.markdown(f"<div class='price-value'>R$ {v1:,.2f}</div>", unsafe_allow_html=True)
                with c_v2:
                    st.markdown("<span class='price-label'>2ª Praça:</span>", unsafe_allow_html=True)
                    st.markdown(f"<div class='price-value-2'>📉 R$ {v2:,.2f}</div>", unsafe_allow_html=True)
                
                st.markdown("---")
                link = row.get('link_detalhe', '#')
                st.markdown(f"🔗 <a href='{link}' target='_blank' class='link-edital'>Ver Edital no Site</a>", unsafe_allow_html=True)

            # --- 3. COLUNA DE AÇÃO (TRIAGEM) ---
            with col_action:
                st.write("**Decisão**")
                
                # Recupera o estado anterior se existir para manter a seleção ao recarregar
                key = f"decision_{id_leilao}"
                
                # Radio Button para decisão rápida
                decision = st.radio(
                    "Decisão para o ID " + id_leilao, # Label invisível, mas necessário para acessibilidade
                    options=["Pendente", "Analisar", "Descartar"],
                    index=2, # <--- 0=Pendente, 1=Analisar, 2=Descartar
                    key=key,
                    label_visibility="collapsed" # Esconde o label para ficar mais limpo
                )
                
                # Se a decisão mudou de "Pendente", guardamos no dict de retorno
                if decision != "Pendente":
                    decisions[id_leilao] = {
                        "id_leilao": id_leilao,
                        "site": row.get('site'),
                        "decisao": decision
                    }
            
            # Adiciona um espaçamento visual entre os cards
            st.write("") 
            st.write("") 

    return decisions

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/components/triage_cards.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/components/sidebar.py ====
import streamlit as st

def render_sidebar(unique_ufs, unique_cities, unique_types, unique_sites):
    st.sidebar.header("🔍 Filtros de Busca")
    
    # Filtro UF
    selected_uf = st.sidebar.multiselect(
        "Estado (UF)",
        options=sorted(unique_ufs) if unique_ufs else [],
        default=[]
    )
    
    # Filtro Cidade (lógica de dependência da UF se necessário, ou simples)
    # Aqui assumimos que unique_cities já vem filtrado ou mostra tudo
    selected_city = st.sidebar.multiselect(
        "Cidade",
        options=sorted(unique_cities) if unique_cities else [],
        default=[]
    )
    
    # Filtro Tipo
    selected_type = st.sidebar.multiselect(
        "Tipo do Bem",
        options=sorted(unique_types) if unique_types else [],
        default=[]
    )
    
    # Filtro Site
    selected_site = st.sidebar.multiselect(
        "Leiloeiro / Site",
        options=sorted(unique_sites) if unique_sites else [],
        default=[]
    )
    
    return {
        "uf": selected_uf,
        "cidade": selected_city,
        "tipo_bem": selected_type,
        "site": selected_site
    }

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/components/sidebar.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/components/dashboard.py ====
import streamlit as st
import pandas as pd
import plotly.express as px  # Nova importação para gráficos bonitos

def render_dashboard(df: pd.DataFrame, stats_history: dict = None):
    """
    Renderiza o painel de indicadores com gráficos de Pizza/Donut.
    """
    if not stats_history:
        stats_history = {'analisar': 0, 'descartar': 0}

    st.markdown("### 📊 Visão Geral")

    # --- LINHA 1: KPIs GERAIS (Métricas continuam iguais) ---
    c1, c2, c3, c4 = st.columns(4)
    
    with c1:
        total_pendente = len(df)
        st.metric("📌 Pendentes", total_pendente, help="Fila de espera")
    
    with c2:
        vol_total = df['valor_1_praca'].sum() if not df.empty and 'valor_1_praca' in df.columns else 0
        st.metric("💰 Volume (1ª Praça)", f"R$ {vol_total/1_000_000:.1f}M")

    with c3:
        st.metric("🗑️ Descartados", stats_history.get('descartar', 0))
        
    with c4:
        count_analisar = stats_history.get('analisar', 0)
        total_proc = stats_history.get('total_processado', 1) or 1
        st.metric("⭐ Para Análise", count_analisar, delta=f"{(count_analisar/total_proc)*100:.0f}% Aprov")

    st.markdown("---")

    # --- LINHA 2: GRÁFICOS DE PIZZA (DONUT) ---
    if not df.empty:
        col_chart1, col_chart2 = st.columns(2)
        
        # --- GRÁFICO 1: TIPO DE BEM ---
        with col_chart1:
            if 'tipo_bem' in df.columns:
                # Prepara os dados: Conta quantos de cada tipo
                counts_tipo = df['tipo_bem'].value_counts().reset_index()
                counts_tipo.columns = ['Tipo', 'Qtd']
                
                # Cria o gráfico Donut
                fig_tipo = px.pie(
                    counts_tipo, 
                    names='Tipo', 
                    values='Qtd', 
                    title='🏢 Distribuição por Tipo',
                    hole=0.4, # Faz o buraco no meio (Donut)
                    color_discrete_sequence=px.colors.qualitative.Pastel
                )
                # Ajustes visuais (fundo transparente para combinar com tema dark)
                fig_tipo.update_layout(height=350, margin=dict(l=20, r=20, t=40, b=20))
                st.plotly_chart(fig_tipo, use_container_width=True)

        # --- GRÁFICO 2: TOP LEILOEIROS ---
        with col_chart2:
            if 'site' in df.columns:
                # Prepara os dados: Conta quantos de cada site
                counts_site = df['site'].value_counts().reset_index()
                counts_site.columns = ['Site', 'Qtd']
                
                # Se tiver muitos sites, pega o Top 5 e agrupa o resto em "Outros" (Opcional, mas recomendado)
                if len(counts_site) > 6:
                    top_5 = counts_site.head(5)
                    outros = pd.DataFrame([['Outros', counts_site.iloc[5:]['Qtd'].sum()]], columns=['Site', 'Qtd'])
                    counts_site = pd.concat([top_5, outros])

                # Cria o gráfico Donut
                fig_site = px.pie(
                    counts_site, 
                    names='Site', 
                    values='Qtd', 
                    title='⚖️ Top Leiloeiros',
                    hole=0.4,
                    color_discrete_sequence=px.colors.qualitative.Set3
                )
                fig_site.update_layout(height=350, margin=dict(l=20, r=20, t=40, b=20))
                st.plotly_chart(fig_site, use_container_width=True)
    
    st.markdown("---")

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/components/dashboard.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/components/triage_grid.py ====
import streamlit as st
import pandas as pd

def render_triage_grid(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()

    # --- SANITIZAÇÃO ---
    cols_visualizacao = ["imagem_capa", "titulo", "valor_1_praca", 
                         "valor_2_praca", "link_detalhe", "site", "id_leilao", "decisao"]
    
    df_clean = df[[c for c in cols_visualizacao if c in df.columns]].copy()
    df_clean = df_clean.head(15).reset_index(drop=True)

    if "titulo" in df_clean.columns:
        df_clean["titulo"] = df_clean["titulo"].astype(str).fillna("")
    if "valor_1_praca" in df_clean.columns:
        df_clean["valor_1_praca"] = pd.to_numeric(df_clean["valor_1_praca"], errors='coerce').fillna(0.0)
    if "valor_2_praca" in df_clean.columns:
        df_clean["valor_2_praca"] = pd.to_numeric(df_clean["valor_2_praca"], errors='coerce').fillna(0.0)

    st.info(f"👇 Exibindo **{len(df_clean)}** itens (Máximo de 15 por página).")

    # --- CONFIG ---
    column_config = {
        
        "imagem_capa": st.column_config.ImageColumn("📸 Foto", width="large"),
        "titulo": st.column_config.TextColumn("Descrição", width="large"),
        "valor_1_praca": st.column_config.NumberColumn("💰 1ª Praça", format="R$ %.2f", width="small"),
        "valor_2_praca": st.column_config.NumberColumn("💰 2ª Praça", format="R$ %.2f", width="small"),
        "link_detalhe": st.column_config.LinkColumn("Edital", display_text="🔗 Link", width="small"),
        "site": st.column_config.Column("Site", width="small", disabled=True), 
        "id_leilao": st.column_config.Column("ID", width="small", disabled=True),
        "decisao": st.column_config.SelectboxColumn("Triagem", options=["Pendente", "Analisar", "Descartar"], width="medium", required=True)
    }

    # --- ALTURA ---
    rows = len(df_clean)
    dynamic_height = (rows * 150) + 42

    edited_df = st.data_editor(
        df_clean,
        column_config=column_config,
        use_container_width=True,
        hide_index=True,
        key=f"triage_grid_{rows}",
        height=dynamic_height,
        num_rows="fixed",
        disabled=["imagem_capa", "valor_1_praca", "valor_2_praca", "titulo", "link_detalhe", "site", "id_leilao"]
    )
    
    return edited_df

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/components/triage_grid.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/components/__init__.py ====
from .sidebar import render_sidebar
from .dashboard import render_dashboard
from .triage_grid import render_triage_grid # Pode manter por segurança
from .triage_cards import render_triage_cards # <--- ADICIONE ESTE

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/presentation/streamlit_app/components/__init__.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/infra/database/config.py ====
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# Em produção, use variáveis de ambiente. Ex: os.getenv("DB_URL")
DATABASE_URL = "postgresql+psycopg2://postgres:postgres@localhost:5432/postgres"

engine = create_engine(DATABASE_URL, echo=False)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    """Dependency injection para sessões de banco."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/infra/database/config.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/infra/database/models_sql.py ====
from sqlalchemy import Column, String, Integer, Float, DateTime, Numeric, Text
from datetime import datetime
from src.infra.database.config import Base

class LeilaoAnaliticoModel(Base):
    __tablename__ = "leiloes_analiticos"

    site = Column(Text, primary_key=True)
    id_leilao = Column(Text, primary_key=True)
    
    id_registro_bruto = Column(Integer) # Vamos usar isso para buscar o ID
    titulo = Column(Text)
    tipo_leilao = Column(Text)
    cidade = Column(Text)
    uf = Column(Text)
    valor_1_praca = Column(Numeric(15, 2))
    valor_2_praca = Column(Numeric(15, 2))
    link_detalhe = Column(Text)
    imagem_capa = Column(Text)
    tipo_bem = Column(Text)
    updated_at = Column(DateTime, default=datetime.now)

class LeilaoAvaliacaoModel(Base):
    __tablename__ = "leiloes_avaliacoes"
    
    usuario_id = Column(Text, primary_key=True)
    site = Column(Text, primary_key=True)
    id_leilao = Column(Text, primary_key=True)
    
    # CORREÇÃO: Adicionada esta coluna que o banco exige
    id_registro_bruto = Column(Integer, nullable=False) 
    
    avaliacao = Column(Text)
    data_analise = Column(DateTime, default=datetime.now)

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/infra/database/models_sql.py ====

# ==== Início do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/infra/repositories/postgres_repo.py ====
from typing import List, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import text, and_, func, distinct

from src.application.interfaces import AuctionRepository
from src.domain.models import Auction, AuctionFilter, Evaluation
from src.infra.database.models_sql import LeilaoAnaliticoModel, LeilaoAvaliacaoModel

class PostgresAuctionRepository(AuctionRepository):
    def __init__(self, session: Session):
        self.session = session

    def get_pending_auctions(self, user_id: str, filters: AuctionFilter) -> List[Auction]:
        # Inicia a query base (Left Join para pegar apenas o que NÃO foi avaliado)
        query = self.session.query(LeilaoAnaliticoModel).outerjoin(
            LeilaoAvaliacaoModel,
            and_(
                LeilaoAnaliticoModel.site == LeilaoAvaliacaoModel.site,
                LeilaoAnaliticoModel.id_leilao == LeilaoAvaliacaoModel.id_leilao,
                LeilaoAvaliacaoModel.usuario_id == user_id
            )
        ).filter(LeilaoAvaliacaoModel.id_leilao == None)

        # --- CORREÇÃO AQUI ---
        # Usamos .in_(...) em vez de == porque os filtros vêm como lista (ex: ['SP'])
        
        if filters.uf:
            query = query.filter(LeilaoAnaliticoModel.uf.in_(filters.uf))
            
        if filters.cidade:
            query = query.filter(LeilaoAnaliticoModel.cidade.in_(filters.cidade))
            
        if filters.tipo_bem:
            query = query.filter(LeilaoAnaliticoModel.tipo_bem.in_(filters.tipo_bem))
            
        if filters.site:
            query = query.filter(LeilaoAnaliticoModel.site.in_(filters.site))
        
        # ---------------------

        results = query.limit(100).all()

        return [
            Auction(
                site=r.site,
                id_leilao=r.id_leilao,
                titulo=r.titulo,
                uf=r.uf,
                cidade=r.cidade,
                tipo_leilao=r.tipo_leilao,
                tipo_bem=r.tipo_bem,
                valor_1_praca=float(r.valor_1_praca) if r.valor_1_praca else 0.0,
                valor_2_praca=float(r.valor_2_praca) if r.valor_2_praca else 0.0,
                link_detalhe=r.link_detalhe,
                imagem_capa=r.imagem_capa
            )
            for r in results
        ]

    def save_evaluations(self, evaluations: List[Evaluation]) -> int:
        count = 0
        try:
            for ev in evaluations:
                # Busca o ID bruto original para manter integridade
                raw_id = self.session.query(LeilaoAnaliticoModel.id_registro_bruto)\
                    .filter_by(site=ev.site, id_leilao=ev.id_leilao)\
                    .scalar()
                
                if raw_id is None: continue

                db_model = LeilaoAvaliacaoModel(
                    usuario_id=ev.usuario_id,
                    site=ev.site,
                    id_leilao=ev.id_leilao,
                    id_registro_bruto=raw_id,
                    avaliacao=ev.avaliacao.value,
                    data_analise=ev.data_analise
                )
                self.session.merge(db_model)
                count += 1
            self.session.commit()
            return count
        except Exception as e:
            self.session.rollback()
            raise e

    def get_filter_options(self) -> Dict[str, List[str]]:
        """Busca valores únicos no banco para preencher os filtros"""
        return {
            "ufs": [r[0] for r in self.session.query(distinct(LeilaoAnaliticoModel.uf)).order_by(LeilaoAnaliticoModel.uf).all() if r[0]],
            "cidades": [r[0] for r in self.session.query(distinct(LeilaoAnaliticoModel.cidade)).order_by(LeilaoAnaliticoModel.cidade).all() if r[0]],
            "tipos": [r[0] for r in self.session.query(distinct(LeilaoAnaliticoModel.tipo_bem)).order_by(LeilaoAnaliticoModel.tipo_bem).all() if r[0]],
            "sites": [r[0] for r in self.session.query(distinct(LeilaoAnaliticoModel.site)).order_by(LeilaoAnaliticoModel.site).all() if r[0]],
        }

    def get_stats(self, user_id: str) -> Dict[str, int]:
        """CONTA REAIS: Quantos 'Analisar' e quantos 'Descartar'."""
        try:
            results = self.session.query(
                LeilaoAvaliacaoModel.avaliacao,
                func.count(LeilaoAvaliacaoModel.id_leilao)
            ).filter(LeilaoAvaliacaoModel.usuario_id == user_id)\
             .group_by(LeilaoAvaliacaoModel.avaliacao).all()
            
            # Inicializa zerado
            stats = {'analisar': 0, 'descartar': 0, 'total_processado': 0}
            
            # Preenche com o retorno do banco
            for status, count in results:
                if status == 'Analisar':
                    stats['analisar'] = count
                elif status == 'Descartar':
                    stats['descartar'] = count
            
            stats['total_processado'] = stats['analisar'] + stats['descartar']
            return stats
        except Exception:
            return {'analisar': 0, 'descartar': 0, 'total_processado': 0}

# ==== Fim do arquivo: /home/cocatis/Projeto_n8n/garimpo_judicial/src/infra/repositories/postgres_repo.py ====
